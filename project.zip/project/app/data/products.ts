export interface Product {
  id: number;
  name: string;
  price: string;
  description: string;
  image: string;
  colors: string[];
  sizes?: string[];
  details: string[];
}

export const products = {
    clothing: [
      {
        id: 1,
        name: "Knit Vest",
        price: "¥45,000",
        image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=500&q=80",
        colors: ["gray", "black"],
        description: "Luxurious knit vest with a contemporary design. Perfect for layering in any season.",
        sizes: ["XS", "S", "M", "L", "XL"],
        details: [
          "100% Premium Wool",
          "Ribbed V-neckline",
          "Relaxed fit",
          "Dry clean only"
        ]
      },
      {
        id: 2,
        name: "Clem Blouse",
        price: "¥36,300",
        image: "https://images.unsplash.com/photo-1551799517-eb8f03cb5e6a?w=500&q=80",
        colors: ["black"],
        description: "Elegant blouse with delicate details. A versatile piece for your wardrobe.",
        sizes: ["XS", "S", "M", "L"],
        details: [
          "100% Silk",
          "Button closure",
          "Regular fit",
          "Hand wash cold"
        ]
      },
      {
        id: 3,
        name: "Fringe Knit",
        price: "¥44,500",
        image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=500&q=80",
        colors: ["gray"],
        description: "Stylish knit sweater with fringe details. Perfect for a cozy yet fashionable look.",
        sizes: ["S", "M", "L"],
        details: [
          "Wool blend",
          "Fringe detail",
          "Oversized fit",
          "Dry clean recommended"
        ]
      },
      {
        id: 4,
        name: "Trinity Dress",
        price: "¥46,200",
        image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&q=80",
        colors: ["blue"],
        description: "Elegant dress with modern silhouette. Perfect for special occasions.",
        sizes: ["XS", "S", "M", "L"],
        details: [
          "Premium fabric blend",
          "Hidden zip closure",
          "Lined",
          "Dry clean only"
        ]
      },
      {
        id: 5,
        name: "Tweed Pocket Jacket",
        price: "¥24,200",
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=500&q=80",
        colors: ["beige"],
        description: "Classic tweed jacket with modern details. A timeless addition to your wardrobe.",
        sizes: ["XS", "S", "M", "L", "XL"],
        details: [
          "Cotton-wool blend",
          "Front button closure",
          "Multiple pockets",
          "Dry clean only"
        ]
      }
    ],
    bags: [
      {
        id: 6,
        name: "Leather Tote Bag",
        price: "¥58,000",
        image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=500&q=80",
        colors: ["black", "brown"],
        description: "Spacious leather tote perfect for daily use. Features premium materials and craftsmanship.",
        details: [
          "Genuine leather",
          "Cotton lining",
          "Interior zip pocket",
          "Magnetic closure"
        ]
      },
      {
        id: 7,
        name: "Mini Crossbody",
        price: "¥42,000",
        image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=500&q=80",
        colors: ["beige"],
        description: "Compact crossbody bag perfect for essentials. Elegant and practical design.",
        details: [
          "Premium leather",
          "Adjustable strap",
          "Multiple compartments",
          "Zip closure"
        ]
      },
      {
        id: 8,
        name: "Structured Bucket Bag",
        price: "¥49,500",
        image: "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=500&q=80",
        colors: ["black", "navy"],
        description: "Modern bucket bag with structured design. Perfect blend of style and functionality.",
        details: [
          "Smooth leather",
          "Drawstring closure",
          "Interior pockets",
          "Protective feet"
        ]
      },
      {
        id: 9,
        name: "Woven Shoulder Bag",
        price: "¥36,800",
        image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=500&q=80",
        colors: ["natural"],
        description: "Artisanal woven bag with leather details. Perfect for casual outings.",
        details: [
          "Woven straw",
          "Leather trim",
          "Cotton lining",
          "Magnetic snap"
        ]
      }
    ],
    shoes: [
      {
        id: 10,
        name: "Classic Loafers",
        price: "¥48,000",
        image: "https://images.unsplash.com/photo-1573100244393-bab7d0dcc4d9?w=500&q=80",
        colors: ["black", "brown"],
        description: "Timeless loafers crafted from premium leather. Perfect for any occasion.",
        sizes: ["35", "36", "37", "38", "39", "40"],
        details: [
          "Calfskin leather",
          "Leather sole",
          "Padded insole",
          "Made in Italy"
        ]
      },
      {
        id: 11,
        name: "Ankle Boots",
        price: "¥62,000",
        image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500&q=80",
        colors: ["black"],
        description: "Sophisticated ankle boots with modern design. Perfect for day to night wear.",
        sizes: ["35", "36", "37", "38", "39", "40"],
        details: [
          "Premium leather",
          "Side zip closure",
          "Stacked heel",
          "Leather lined"
        ]
      },
      {
        id: 12,
        name: "Ballet Flats",
        price: "¥32,000",
        image: "https://images.unsplash.com/photo-1536830220630-ce146cccac84?w=500&q=80",
        colors: ["beige", "black"],
        description: "Classic ballet flats with modern comfort features. Perfect for everyday wear.",
        sizes: ["35", "36", "37", "38", "39", "40"],
        details: [
          "Soft leather",
          "Cushioned insole",
          "Flexible sole",
          "Made in Italy"
        ]
      },
      {
        id: 13,
        name: "Leather Sandals",
        price: "¥28,500",
        image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500&q=80",
        colors: ["tan", "black"],
        description: "Minimalist leather sandals perfect for warm weather. Comfortable and stylish.",
        sizes: ["35", "36", "37", "38", "39", "40"],
        details: [
          "Genuine leather",
          "Adjustable straps",
          "Rubber sole",
          "Anatomical footbed"
        ]
      }
    ],
    accessories: [
      {
        id: 14,
        name: "Pearl Necklace",
        price: "¥24,000",
        image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500&q=80",
        colors: ["pearl"],
        description: "Elegant pearl necklace with modern design. Perfect for special occasions.",
        details: [
          "Freshwater pearls",
          "Sterling silver clasp",
          "Adjustable length",
          "Gift box included"
        ]
      },
      {
        id: 15,
        name: "Leather Belt",
        price: "¥18,500",
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&q=80",
        colors: ["black", "brown"],
        description: "Classic leather belt with timeless design. Perfect for everyday wear.",
        details: [
          "Full-grain leather",
          "Brass buckle",
          "Hand-stitched",
          "Made in Japan"
        ]
      },
      {
        id: 16,
        name: "Silk Scarf",
        price: "¥22,000",
        image: "https://images.unsplash.com/photo-1601999109332-542b18dbec57?w=500&q=80",
        colors: ["multicolor"],
        description: "Luxurious silk scarf with artistic print. Versatile accessory for any outfit.",
        details: [
          "100% silk",
          "Hand-rolled edges",
          "Original print",
          "Made in Italy"
        ]
      },
      {
        id: 17,
        name: "Gold Earrings",
        price: "¥16,800",
        image: "https://images.unsplash.com/photo-1630019852942-f89202989a59?w=500&q=80",
        colors: ["gold"],
        description: "Delicate gold earrings with modern design. Perfect for everyday elegance.",
        details: [
          "18k gold plated",
          "Nickel-free",
          "Butterfly closure",
          "Gift box included"
        ]
      }
    ]
  };