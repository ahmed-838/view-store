"use client";

import { ShoppingBag, Search, Menu } from "lucide-react";
import { useState, useEffect } from "react";
import Link from "next/link";
import { products } from "@/app/data/products";
import Navbar from "./navbar/Navbar";
import { useRouter } from "next/navigation";

export default function Home() {
  const [cartCount] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const router = useRouter();

  const getFilteredProducts = () => {
    if (selectedCategory === "all") {
      return Object.values(products).flat();
    }
    return products[selectedCategory as keyof typeof products] || [];
  };

  const filteredProducts = getFilteredProducts();

  const handleProductClick = (productId: number) => {
    router.push(`/product?id=${productId}`);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar setSelectedCategory={setSelectedCategory} />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <h2 className="text-2xl font-light text-center mb-12">
          {selectedCategory === "all" ? "All Products" : selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div onClick={() => handleProductClick(product.id)} className="group cursor-pointer">
              <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-lg bg-gray-100">
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-full w-full object-cover object-center group-hover:opacity-75"
                />
                <div className="absolute bottom-2 left-2 flex gap-1">
                  {product.colors.map((color, index) => (
                    <div
                      key={index}
                      className="w-4 h-4 rounded-full border border-white"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
              <div className="mt-4 flex justify-between">
                <div>
                  <h3 className="text-sm text-gray-700">{product.name}</h3>
                  <p className="mt-1 text-sm text-gray-500">{product.price}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-sm font-medium text-gray-900">Navigation</h3>
              <ul className="mt-4 space-y-2">
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">All Products</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Clothing</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Bags</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Shoes</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Accessories</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-900">Follow us</h3>
              <ul className="mt-4 space-y-2">
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Instagram</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Facebook</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Twitter</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Pinterest</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-900">Legal</h3>
              <ul className="mt-4 space-y-2">
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Privacy Policy</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Terms of Service</a></li>
                <li><a href="#" className="text-sm text-gray-600 hover:text-gray-900">Returns</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-900">Newsletter</h3>
              <p className="mt-4 text-sm text-gray-600">Subscribe to our newsletter for updates and exclusive offers.</p>
              <form className="mt-4">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full px-4 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
                />
                <button
                  type="submit"
                  className="w-full mt-2 px-4 py-2 text-sm text-white bg-black rounded-md hover:bg-gray-900"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t">
            <p className="text-sm text-center text-gray-500">&copy; 2025 RUMUSHA. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}