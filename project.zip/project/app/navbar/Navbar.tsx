import { Menu, Search, ShoppingBag } from "lucide-react";
import Link from "next/link";
import { useState, useEffect } from "react";

const Navbar = ({ setSelectedCategory }: { setSelectedCategory: (category: string) => void }) => {
  const [selectedCategory, setSelectedCategoryState] = useState("all");
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    console.log(`Selected category: ${selectedCategory}`);
  }, [selectedCategory]);

  return (
    <div className="border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex justify-between items-center h-16">
          {/* Left - Menu (Mobile) */}
          <div className="lg:hidden">
            <button className="text-gray-600 hover:text-gray-900">
              <Menu className="h-6 w-6" />
            </button>
          </div>

          {/* Center - Logo */}
          <div className="flex-1 flex items-center justify-center lg:justify-start">
            <Link href="/" className="text-2xl font-serif tracking-wider">
              RUMUSHA
            </Link>
          </div>

          {/* Right - Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <button 
              onClick={() => setSelectedCategory("all")}
              className={`text-sm ${selectedCategory === "all" ? "text-black font-medium" : "text-gray-600"} hover:text-gray-900`}
            >
              All Products
            </button>
            <button 
              onClick={() => setSelectedCategory("clothing")}
              className={`text-sm ${selectedCategory === "clothing" ? "text-black font-medium" : "text-gray-600"} hover:text-gray-900`}
            >
              Clothing
            </button>
            <button 
              onClick={() => setSelectedCategory("bags")}
              className={`text-sm ${selectedCategory === "bags" ? "text-black font-medium" : "text-gray-600"} hover:text-gray-900`}
            >
              Bags
            </button>
            <button 
              onClick={() => setSelectedCategory("shoes")}
              className={`text-sm ${selectedCategory === "shoes" ? "text-black font-medium" : "text-gray-600"} hover:text-gray-900`}
            >
              Shoes
            </button>
            <button 
              onClick={() => setSelectedCategory("accessories")}
              className={`text-sm ${selectedCategory === "accessories" ? "text-black font-medium" : "text-gray-600"} hover:text-gray-900`}
            >
              Accessories
            </button>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900">About us</a>
          </nav>

          {/* Right - Icons */}
          <div className="flex items-center space-x-4">
            <button className="text-gray-600 hover:text-gray-900">
              <Search className="h-5 w-5" />
            </button>
            <button className="text-gray-600 hover:text-gray-900 relative">
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;